export default class SpanTime {

    constructor() {
        this._time      = "00";
        this._color     = "aliceblue";
        this._width     = "20px";
        this._height    = "20px";

        this.gerarSpamTime();
    }

    set text(value){
        this.elemento.textContent = value;
    }

    gerarSpamTime() {
        
        this.elemento = document.createElement("span");

        Object.assign(this.elemento.style, {
            width: this._width,
            height: this._height,
            color: this._color
        });

        this.elemento.textContent = this._time;
    }
}