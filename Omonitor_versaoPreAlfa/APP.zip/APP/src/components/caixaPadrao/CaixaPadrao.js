import gerarIdElemento from "../../javascript/utils/geraIdElemento.js";
import obterIdPai from "../../javascript/services/obterIdPai.js";
import desaparecer from "../../javascript/behaviors/desaparecer.js";
import aparecer from "../../javascript/behaviors/aparecer.js";
import toggleVisibilidade from "../../javascript/behaviors/toggleVisibilidade.js";

export default class CaixaPadrao {

    constructor( objMovel , temFilho , souFilho ){

        this._validaEntrada(objMovel, temFilho, souFilho);

        this._temFilho               = temFilho;
        this._souFilho               = souFilho;
        this._objMovel               = objMovel;
        this.isDragging              = false;
        this.offsetX                 = 0;
        this.offsetY                 = 0;
        this._id                     = souFilho?"":gerarIdElemento("001" , null , "00");
        this._removConfgPadJaChamada = false;

        this._tamanhoPercentuaFilhoComparadoAoElementoPai= 0.8;

        this._width             = "80%";
        this._height            = "60%";
        this._backgroundColor   = "#ff0000";
        this._display           = "flex";
        this._position          = "absolute";
        this._left              = "50%";
        this._right             = "0%";
        this._top               = "50%";
        this._transform         = "translate(-50%, -50%)";
        this._borderRadius      = "5px";
        this._justifyContent    = "center";
        this._alignItems        = "center";
        this._padding           = "10px";
        this._boxShadow         = "0px 0px 10px 10px rgba(0,0,0,0.5)";
        this._flexDirection     = "column";
        this._borderRight       = "2px solid white";
        this._borderLeft        = "2px solid white"; 
        this._cursor            = "pointer";
        this._overFlow          = "scroll";
        this._overflow_x        = "hidden";
        this._overflowY         = "none";
        this._wordWrap          = "break-word";
        this._textContent       = " ";
        this._color             = "#dadada";
        this._marginBottom      = "20px";
        this._flexWrap          ="";
        this._boxSizing         ="";

        this.gerarCaixaPadrao();

        if (this._objMovel) {
            this.caixaPadrao.addEventListener("mousedown", (e) => this._mouseDownEvent(e));
            document.addEventListener("mousemove", (e) => this._mouseMoveEvent(e));
            document.addEventListener("mouseup", (e) => this._mouseUpEvent(e));
        }

        if(this._temFilho){
            this._caixaFilha = new CaixaPadrao(false , this._temFilho-1 , true);
            this._caixaFilhaConfg();
            this.caixaPadrao.appendChild(this._caixaFilha.caixaPadrao);

        }

    }



    get getWidth()              { return this._width; }
    get getHeight()             { return this._height; }
    get getBackgroundColor()    { return this._backgroundColor; }
    get getDisplay()            { return this._display; }
    get getPosition()           { return this._position; }
    get getLeft()               { return this._left; }
    get getRight()              { return this._right; }
    get getTop()                { return this._top; }
    get getBorderRadius()       { return this._borderRadius; }
    get getJustifyContent()     { return this._justifyContent; }
    get getAlignItems()         { return this._alignItems; }
    get getPadding()            { return this._padding; }
    get getBoxShadow()          { return this._boxShadow; }
    get getFlexDirection()      { return this._flexDirection; }
    get getOrientacao()         { return this._orientacao; }
    get getMapComBotoes()       { return this._mapComBotoes; }
    get getCaixaFilha()         { return this._caixaFilha;}
    get getCaixaNeta()          { return this._caixaFilha.getCaixaFilha;}
    get getId()                 { return this._id;}

    get getElemento()           { return this.caixaPadrao;}
    get getElementoFilho()      { return this._caixaFilha?this._caixaFilha.caixaPadrao:null;}
    get getElementoNeto()       { return this._caixaFilha.getCaixaFilha.caixaPadrao;}

    set atribuirWidth(value) {
        this._width = value;
        this._updateStyle("width", value);
    }

    set atribuirHeight(value) {
        this._height = value;
        this._updateStyle("height", value);
    }

    set atribuirBackgroundColor(value) {
        this._backgroundColor = value;
        this._updateStyle("backgroundColor", value);
    }

    set atribuirDisplay(value) {
        this._display = value;
        this._updateStyle("display", value);
    }

    set atribuirPosition(value) {
        this._position = value;
        this._updateStyle("position", value);
    }

    set atribuirLeft(value) {

        
        if(!this._removConfgPadJaChamada){this._removerConfiguracaoPosicaoPadrao();}
        
        this._left = value;
        this._updateStyle("left", value);
        
    }

    set atribuirRight(value) {


        if(!this._removConfgPadJaChamada){this._removerConfiguracaoPosicaoPadrao();}
        
        this._right = value;
        this._updateStyle("right", value);
        
    }

    set atribuirTop(value) {

        if(!this._removConfgPadJaChamada){this._removerConfiguracaoPosicaoPadrao();}

        this._top = value;
        this._updateStyle("top", value);
    }

    set atribuirBorderRadius(value) {
        this._borderRadius = value;
        this._updateStyle("borderRadius", value);
    }

    set atribuirJustifyContent(value) {
        this._justifyContent = value;
        this._updateStyle("justifyContent", value);
    }

    set atribuirAlignItems(value) {
        this._alignItems = value;
        this._updateStyle("alignItems", value);
    }

    set atribuirPadding(value) {
        this._padding = value;
        this._updateStyle("padding", value);
    }

    set atribuirBoxShadow(value) {
        this._boxShadow = value;
        this._updateStyle("boxShadow", value);
    }

    set atribuirFlexDirection(value) {
        this._flexDirection = value;
        this._updateStyle("flexDirection", value);
    }

    set atribuirColor(value) {
        this._color = value;
        this._updateStyle("color", value);
    }

    set atribuirTextContent(text){
         if(this.caixaPadrao){
          this.caixaPadrao.textContent = text;
    }
    }

    set atribuirOverflow(value){
         this._overFlow=value;
          this._updateStyle("overflow", value);
    }
    
    
    set atribuirId(value){
         this._id=value;
    }

    set atribuirTransform(value){
        this._transform=value;
        this._updateStyle("transform", value);
    }

    set atribuirFlexWrap(value){
        this._flexWrap=value;
        this._updateStyle("flexWrap", value);
    }

    
    _validaEntrada(objMovel, temFilho, souFilho){

        if(typeof objMovel !== "boolean"){
            throw new TypeError(
                "objMovel precisa ser boolean (true ou false)"
            );
        }

        const temFilhoValido =
            typeof temFilho === "boolean" ||
            (
                typeof temFilho === "number" &&
                Number.isInteger(temFilho) &&
                temFilho >= 0 &&
                temFilho <= 3
            );

        if(!temFilhoValido){
            throw new TypeError(
                "temFilho precisa ser boolean ou número inteiro entre 0 e 3"
            );
        }

        if(typeof souFilho !== "boolean"){
            throw new TypeError(
                "souFilho precisa ser boolean (true ou false)"
            );
        }

        return true;
    }
    
    _caixaFilhaConfg(){

        this._caixaFilha.atribuirWidth=parseFloat(this._width) * this._tamanhoPercentuaFilhoComparadoAoElementoPai;
        this._caixaFilha.atribuirHeight="auto";
        this._caixaFilha.atribuirBackgroundColor="blue";
        this._caixaFilha.atribuirDisplay="inline-block";
        this._caixaFilha.atribuirFlexWrap       = "nowrap";
        this._caixaFilha.atribuirFlexDirection  = "row";

        this._caixaFilha.atribuirId= gerarIdElemento("001", this._id , "02");
    }

    _mouseDownEvent(e){
        this.isDragging = true;

        this.offsetX = e.clientX - this.caixaPadrao.offsetLeft;
        this.offsetY = e.clientY - this.caixaPadrao.offsetTop;

        this.caixaPadrao.style.transform = "none";
    }

    _mouseMoveEvent(e){
        if (!this.isDragging) return;

        this.caixaPadrao.style.left = `${e.clientX - this.offsetX}px`;
        this.caixaPadrao.style.top = `${e.clientY - this.offsetY}px`;
    }

    _mouseUpEvent(e){
         this.isDragging = false;
    }

    _mouseMoveEventParaWindow(e){
        position_x=evento.clientX
        position_y=evento.clientY

        let rotate= Math.atan2(position_y,position_x)*180/Math.PI

        console.log(rotate)

    }

    _updateStyle(prop, value) {
        if (this.caixaPadrao) {
            this.caixaPadrao.style[prop] = value;
        }
    }

    _renderButtons() {
        if (!this.caixaPadrao) return;

        this.caixaPadrao.innerHTML = "";

        for (let botao of this._mapComBotoes.values()) {
            if (botao && typeof botao.getElement === "function") {
                this.caixaPadrao.appendChild(botao.getElement());
            } else {
                console.warn("Botão inválido ignorado:", botao);
            }
        }
    }

    _removerConfiguracaoPosicaoPadrao() {
        this._transform = "none";
        this._top = "0%";
        this._left = "0%";
        this._right = "0%";
        this._position = "relative";

        this._updateStyle("transform", "none");
        this._updateStyle("top", "0%");
        this._updateStyle("left", "0%");
        this._updateStyle("right", "0%");
        this._updateStyle("position", "relative");

        this._removConfgPadJaChamada = true;
    }

    _removerConfiguracaoPadraoScrollbar(nivel = 0){

        this._height            = "auto";
        this._maxHeight         = "none";
        this._overflow          = "visible";
        this._wordWrap          = "break-word";
        this._left              = "50%";
        this._right             = "0%";
        this._top               = "0%";
        this._transform         = "translate( 0%, 0%)";

        if(this.getCaixaFilha){
            this.getCaixaFilha.atribuirPosition="relative";
            this.getCaixaFilha._updateStyle("position" , "relative");
        }  

        this._updateStyle("height", "auto");
        this._updateStyle("maxHeight", "none");
        this._updateStyle("overflow", "visible");
        this._updateStyle("overflowY", "visible");
        this._updateStyle("overflowX", "visible");
        this._updateStyle("overflowWrap", "break-word");
        this._updateStyle("wordBreak", "break-all");
        this._updateStyle("whiteSpace", "normal");
        this._updateStyle("left", "0%");
        this._updateStyle("right", "0%");
        this._updateStyle("top", "0%");
        this._updateStyle("transform", "translate(0%, 0%)");

        if(nivel > 0 && this.getCaixaFilha){
            this.getCaixaFilha._removerConfiguracaoPadraoScrollbar(nivel - 1);
        }
    }

    _on(event, callback){
        this.caixaPadrao.addEventListener(event, callback);
        return this;
    }

    _aparecer(){
        aparecer(this.caixaPadrao);
    }

    _desaparecer(){
        desaparecer(this.caixaPadrao);
    }

    _toggleVisibilidade(){
        toggleVisibilidade(this.caixaPadrao);
    }

    _addChild(child){

        if(!(this.getElementoFilho==null)){
            console.log(this.getElementoFilho);

            this.getElementoFilho.appendChild(child);
        }else{
            throw new Error("Elemento precisar ter expresamente 1 filho , tente algo como const elemento = new CaixaPadrao(false , 1 , false);");
        }
    }

    gerarCaixaPadrao() {

        this.caixaPadrao = document.createElement("div");

        Object.assign(this.caixaPadrao.style, {

            width:              this._width,
            height:             this._height,
            backgroundColor:    this._backgroundColor,
            display:            this._display,
            position:           this._position,
            top:                this._top,
            borderRadius:       this._borderRadius,
            justifyContent:     this._justifyContent,
            alignItems:         this._alignItems,
            padding:            this._padding,
            boxShadow:          this._boxShadow,
            flexDirection:      this._flexDirection,
            left:               this._left,
            right:              this._right,
            transform:          this._transform,
            cursor:             this._cursor,
            wordWrap:           this._wordWrap,
            overflow:           this._overFlow, 
            overflowX:          this._overflow_x,
            overflowY:          this._overflow_y,
            color:              this._color,
            marginBottom:       this._marginBottom,
            FlexWrap:           this._flexWrap,
            boxSizing:          this._boxSizing,

            
        });

        this.caixaPadrao.classList.add("caixa-scroll");
        document.body.appendChild(this.caixaPadrao);

    }    
}