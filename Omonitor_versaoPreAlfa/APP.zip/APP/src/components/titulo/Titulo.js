export default class Titulo {

    constructor(titulo) {
        this._titulo        = titulo;
        this._width         = "30vh";
        this._height        = "20vh";
        this._color         = "aliceblue";
        this._left          = "10%";
        this._top           = "3%";
        this._position      = "fixed";
        this._whiteSpace    = "nowrap"

        this.gerarTitulo();
    }

    

    get gettitulo() {
        return this._titulo;
    }

    get getWidth() {
        return this._width;
    }

    get getHeight() {
        return this._height;
    }

    get getColor() {
        return this._color;
    }

    get getLeft() {
        return this._left;
    }

    get getTop() {
        return this._top;
    }

    get getPosition() {
        return this._position;
    }

    

    set atribuirTitulo(valor) {
        this._titulo = valor;
    }

    set atribuirWidth(valor) {
        this._width = valor;
    }

    set atribuirHeight(valor) {
        this._height = valor;
    }

    set atribuirColor(valor) {
        this._color = valor;
    }

    set atribuirLeft(valor) {
        this._left = valor;
    }

    set atribuirTop(valor) {
        this._top = valor;
    }

    set atribuirPosition(valor) {
        this._position = valor;
    }

    gerarTitulo() {
        this.elemento = document.createElement("h1");

        Object.assign(this.elemento.style, {
            width:          this._width,
            height:         this._height,
            position:       this._position,
            top:            this._top,
            left:           this._left,
            color:          this._color,
            whiteSpace:     this._whiteSpace,
        });

        this.elemento.textContent = this._titulo;
        document.body.appendChild(this.elemento);
    }
}