export default class Cronometro{

    constructor(){

        this
    }
}