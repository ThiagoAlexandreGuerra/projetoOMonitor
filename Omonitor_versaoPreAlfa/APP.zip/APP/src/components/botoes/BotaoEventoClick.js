import Botao from "./Botao.js";

export default class BotaoEventoClick extends Botao{

    constructor(function_){
        
        super();
        this._function_= function_;
        this.element.addEventListener("click" , this._function_);
        
    }

    set atribuirFunction_(_function_){
        this._function_=_function_;
    }
    
    
}