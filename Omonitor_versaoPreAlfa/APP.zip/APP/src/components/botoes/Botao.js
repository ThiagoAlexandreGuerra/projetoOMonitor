
export default class Botao {

    constructor() {

        this._width                 = "67px";
        this._height                = "67px";
        this._backgroundColor       = "#242424";
        this._marginTop             = "10px";
        this._backgroundImage       = "";
        this._backgroundRepeat      = "no-repeat";
        this._backgroundPosition    = "center";
        this._backgroundSize        = "50px 50px";
        this._border                = "2px solid black";
        this._cursor                = "pointer";
        this._bottom                = "";
        this._display               = "flex";
        this._top                   ="none";
        this._position              ="absolute";
        this._borderRadius          ="8px";

        this.gerarBotao();
        this._adicionarHover();
    }

    
    get getWidth()              { return this._width; }
    get getHeight()             { return this._height; }
    get getBackgroundColor()    { return this._backgroundColor; }
    get getMarginTop()          { return this._marginTop; }
    get getBackgroundImage()    { return this._backgroundImage; }
    get getBackgroundRepeat()   { return this._backgroundRepeat; }
    get getBackgroundPosition() { return this._backgroundPosition; }
    get getBackgroundSize()     { return this._backgroundSize; }
    get getBorder()             { return this._border; }
    get getCursor()             { return this._cursor; }
    get getPosition()           { return this._position;}
    get getBorderRadius()       { return this._borderRadius;}

    get getElement()                {return this.element;}

    
    set atribuirWidth(value) {
        this._width = value;
        this._updateStyle("width", value);
    }

    set atribuirHeight(value) {
        this._height = value;
        this._updateStyle("height", value);
    }

    set atribuirBackgroundColor(value) {
        this._backgroundColor = value;
        this._updateStyle("backgroundColor", value);
    }

    set atribuirMarginTop(value) {
        this._marginTop = value;
        this._updateStyle("marginTop", value);
    }

    set atribuirBackgroundImage(value) {
        this._backgroundImage = value;
        this._updateStyle("backgroundImage", value);
    }

    set atribuirBackgroundRepeat(value) {
        this._backgroundRepeat = value;
        this._updateStyle("backgroundRepeat", value);
    }

    set atribuirBackgroundPosition(value) {
        this._backgroundPosition = value;
        this._updateStyle("backgroundPosition", value);
    }

    set atribuirBackgroundSize(value) {
        this._backgroundSize = value;
        this._updateStyle("backgroundSize", value);
    }

    set atribuirBorder(value) {
        this._border = value;
        this._updateStyle("border", value);
    }

    set atribuirCursor(value) {
        this._cursor = value;
        this._updateStyle("cursor", value);
    }

    set atribuirBottom(value) {
        this._bottom = value;
        this._updateStyle("bottom", value);
    }

    set atribuirTop(value) {
        this._top = value;
        this._updateStyle("top", value);
    }

    set atribuirPosition(value) {
        this._position = value;
        this._updateStyle("position", value);
    }

    set atribuirBorderRadius(value) {
        this._borderRadius = value;
        this._updateStyle("borderRadius", value);
    }

    _updateStyle(prop, value) {
        if (this.element) {
            this.element.style[prop] = value;
        }
    }

    _adicionarHover() {
        this.element.addEventListener("mouseenter", () => {
            this.element.style.transform = "scale(1.05)";
            this.element.style.backgroundColor = "#be000085";
        });

        this.element.addEventListener("mouseleave", () => {
            this.element.style.transform = "scale(1)";
            this.element.style.backgroundColor = this._backgroundColor;
        });
    }

    gerarBotao() {
        this.element = document.createElement("div");

        Object.assign(this.element.style, {

            position:           this._position,
            width:              this._width,
            height:             this._height,
            backgroundColor:    this._backgroundColor,
            marginTop:          this._marginTop,
            borderRadius:       this._borderRadius,
            backgroundImage:    this._backgroundImage,
            backgroundRepeat:   this._backgroundRepeat,
            backgroundPosition: this._backgroundPosition,
            backgroundSize:     this._backgroundSize,
            border:             this._border,
            cursor:             this._cursor,
            bottom:             this._bottom,
            display:            this._display,
            top:                this._top,

        });
    }

    
}