import Botao from "./Botao.js";


export default class BotaoLinkParaOutraPagina extends Botao {

    constructor(linkParaOutraPagina) {
        super();

        this.linkParaOutraPagina = linkParaOutraPagina;

        this.linkElement = this.criarElementoHTMLParaLink(this.linkParaOutraPagina);
        this.element.appendChild(this.linkElement);
    }

    criarElementoHTMLParaLink(link) {
        let elementoParaLink = document.createElement("a");

        elementoParaLink.href = link;
        elementoParaLink.textContent = "Ir"; 

        return elementoParaLink;
    }

    set atribuirLinkDesteBotaoPara(link) {
        this.linkParaOutraPagina = link;

        if (this.linkElement) {
            this.linkElement.href = link;
        }
    }
}