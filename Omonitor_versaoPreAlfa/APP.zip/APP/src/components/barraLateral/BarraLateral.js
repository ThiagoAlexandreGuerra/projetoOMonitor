
export default class BarraLateral {

    constructor(orientacao, mapComBotoes) {

        this._width             = "80px";
        this._height            = "100vh";
        this._backgroundColor   = "#131212";
        this._display           = "flex";
        this._position          = "fixed";
        this._left              = "0px";
        this._right             = "0px";
        this._top               = "0px";
        this._borderRadius      = "5px";
        this._justifyContent    = "flex-start";
        this._alignItems        = "center";
        this._padding           = "10px";
        this._boxShadow         = "0px 0px 10px 10px rgba(0,0,0,0.5)";
        this._flexDirection     = "column";
        this._borderRight       = "2px solid white";
        this._borderLeft        = "2px solid white"; 
        

        this._orientacao = (orientacao || "left").toLowerCase();
        this._mapComBotoes = mapComBotoes || new Map();

        this.gerarBarraLateral();
    }

    get getWidth()              { return this._width; }
    get getHeight()             { return this._height; }
    get getBackgroundColor()    { return this._backgroundColor; }
    get getDisplay()            { return this._display; }
    get getPosition()           { return this._position; }
    get getLeft()               { return this._left; }
    get getRight()              { return this._right; }
    get getTop()                { return this._top; }
    get getBorderRadius()       { return this._borderRadius; }
    get getJustifyContent()     { return this._justifyContent; }
    get getAlignItems()         { return this._alignItems; }
    get getPadding()            { return this._padding; }
    get getBoxShadow()          { return this._boxShadow; }
    get getFlexDirection()      { return this._flexDirection; }
    get getOrientacao()         { return this._orientacao; }
    get getMapComBotoes()       { return this._mapComBotoes; }

    set atribuirWidth(value) {
        this._width = value;
        this._updateStyle("width", value);
    }

    set atribuirHeight(value) {
        this._height = value;
        this._updateStyle("height", value);
    }

    set atribuirBackgroundColor(value) {
        this._backgroundColor = value;
        this._updateStyle("backgroundColor", value);
    }

    set atribuirDisplay(value) {
        this._display = value;
        this._updateStyle("display", value);
    }

    set atribuirPosition(value) {
        this._position = value;
        this._updateStyle("position", value);
    }

    set atribuirLeft(value) {
        this._left = value;
        if (this._orientacao === "left") {
            this._updateStyle("left", value);
        }
    }

    set atribuirRight(value) {
        this._right = value;
        if (this._orientacao === "right") {
            this._updateStyle("right", value);
        }
    }

    set atribuirTop(value) {
        this._top = value;
        this._updateStyle("top", value);
    }

    set atribuirBorderRadius(value) {
        this._borderRadius = value;
        this._updateStyle("borderRadius", value);
    }

    set atribuirJustifyContent(value) {
        this._justifyContent = value;
        this._updateStyle("justifyContent", value);
    }

    set atribuirAlignItems(value) {
        this._alignItems = value;
        this._updateStyle("alignItems", value);
    }

    set atribuirPadding(value) {
        this._padding = value;
        this._updateStyle("padding", value);
    }

    set atribuirBoxShadow(value) {
        this._boxShadow = value;
        this._updateStyle("boxShadow", value);
    }

    set atribuirFlexDirection(value) {
        this._flexDirection = value;
        this._updateStyle("flexDirection", value);
    }

    set atribuirOrientacao(value) {
        const val = (value || "").toLowerCase();
        if (val !== "left" && val !== "right") {
            console.warn("Orientação inválida. Use 'left' ou 'right'");
            return;
        }

        this._orientacao = val;

        if (this.barraLateral) {
            this.barraLateral.style.left = "";
            this.barraLateral.style.right = "";

            if (val === "left") {
                this.barraLateral.style.left = this._left;
            } else {
                this.barraLateral.style.right = this._right;
            }
        }
    }

    set atribuirMapComBotoes(value) {
        if (!(value instanceof Map)) {
            console.warn("mapComBotoes deve ser um Map");
            return;
        }

        this._mapComBotoes = value;
        this._renderButtons();
    }

    _updateStyle(prop, value) {
        if (this.barraLateral) {
            this.barraLateral.style[prop] = value;
        }
    }

    _renderButtons() {
        if (!this.barraLateral) return;

        this.barraLateral.innerHTML = "";

        for (let botao of this._mapComBotoes.values()) {
          if (botao && botao.getElement) {
                this.barraLateral.appendChild(botao.getElement);

            } else {
                console.warn("Botão inválido ignorado:", botao);
            }
        }
    }

    gerarBarraLateral() {
        this.barraLateral = document.createElement("div");

        Object.assign(this.barraLateral.style, {

            width:              this._width,
            height:             this._height,
            backgroundColor:    this._backgroundColor,
            display:            this._display,
            position:           this._position,
            top:                this._top,
            borderRadius:       this._borderRadius,
            justifyContent:     this._justifyContent,
            alignItems:         this._alignItems,
            padding:            this._padding,
            boxShadow:          this._boxShadow,
            flexDirection:      this._flexDirection,
            borderRight:        this._orientacao=="left"?this._borderRight:"" ,
            borderLeft:         this._orientacao=="right"?this._borderLeft:""
            
        });

        this.atribuirOrientacao = this._orientacao; 

        this._renderButtons();

        document.body.appendChild(this.barraLateral);
    }
}