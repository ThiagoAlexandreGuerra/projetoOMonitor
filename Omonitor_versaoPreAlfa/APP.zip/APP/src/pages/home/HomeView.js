import BarraLateral from "../../../src/components/barraLateral/BarraLateral.js";
import Botao from "../../../src/components/botoes/Botao.js";
import BotaoEventoDeClick from "../../../src/components/botoes/BotaoEventoClick.js";
import BotaoLinkParaOutraPagina from "../../../src/components/botoes/BotaoLink.js";
import CaixaPadrao from "../../../src/components/caixaPadrao/CaixaPadrao.js";
import ServeCaminhosProjeto from "../../../src/javascript/services/serveCaminhosProjeto.js";
import Titulo from "../../components/titulo/Titulo.js";
import Relogio from "../../components/relogio/Relogio.js";

export default class HomeView {

    constructor() {
        this.caminhos = new ServeCaminhosProjeto();
    }

    criarLayout(eventos) {
    //TITULO VIEW*********************************************************************************
    //*******************************************************************************************/
    
        const titulo = new Titulo("O Monitor - Pré Alpha");

    //TITULO RELOJO*********************************************************************************
    //*******************************************************************************************/
        
        const relogio = new Relogio();
        
    //BARRA LATERAL ESQUERDA VIEW*****************************************************************
    //*******************************************************************************************/    
        const botaoHome = new Botao();
        const botaoPerfil = new BotaoEventoDeClick(eventos.onRandom);
        const botaoFullscreen = new BotaoEventoDeClick(eventos.onFullscreen);

        botaoHome.atribuirBackgroundImage =
            this.caminhos._serveUrlImage(this.caminhos._homeIcon);

        botaoPerfil.atribuirBackgroundImage =
            this.caminhos._serveUrlImage(this.caminhos.perfilIcon);
        botaoPerfil.atribuirMarginTop="200%";

        botaoFullscreen.atribuirBackgroundImage =
            this.caminhos._serveUrlImage(this.caminhos.openFullscreenIcon);
        botaoFullscreen.atribuirBottom = "5%"
        

        const botoesEsquerda = new Map([
            [1, botaoHome],
            [2, botaoPerfil],
            [3, botaoFullscreen]
        ]);

        new BarraLateral("left", botoesEsquerda);

    //BARRA LATERAL DIREITA VIEW*****************************************************************
    //*******************************************************************************************/ 

        let botaoDireita= new BotaoEventoDeClick(eventos.onGetName);

        let botaoApareceDesapareceRelojo= new BotaoEventoDeClick(()=>eventos.onToggleVisibilidade(relogio.caixaPadrao) )
        botaoApareceDesapareceRelojo.atribuirMarginTop="150%";
        
        let meuBotaoBarraLateralDireita = new Map;
        meuBotaoBarraLateralDireita.set(1, botaoDireita);
        meuBotaoBarraLateralDireita.set(2, botaoApareceDesapareceRelojo);
      

        let barraLateralDireita = new BarraLateral("right" , meuBotaoBarraLateralDireita);
    
    //DISPLAY QUESTÕES VIEW**********************************************************************
    //*******************************************************************************************/ 


        let displayQuestoes = new CaixaPadrao(false , true , false);
        
        displayQuestoes.getCaixaFilha.atribuirTextContent = " 111111111111111111 Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi.  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum sequi esse, laborum dolore tempora natus doloremque adipisci illum deleniti quidem, ex accusantium dicta in quaerat nisi minus a repellendus animi.11111111111111111111111111111 "
        displayQuestoes.atribuirWidth                           ="75%"
        displayQuestoes.getCaixaFilha.atribuirHeight            ="85%";
        displayQuestoes.getCaixaFilha.atribuirWidth             ="95%";
        displayQuestoes.getCaixaFilha.atribuirBoxShadow         ="none"
        displayQuestoes.atribuirBackgroundColor                 ="#111111";
        displayQuestoes.getCaixaFilha.atribuirBackgroundColor   ="#141414" 

        

    //test*****************************************************************************************

        let test = new CaixaPadrao (true , true , false);
        let filho1 = new CaixaPadrao (false , true , false);
        let filho2 = new CaixaPadrao (false , true , false);
        let filho3 = new CaixaPadrao (false , true , false);
        let filho4 = new CaixaPadrao (false , true , false);
        let filho5 = new CaixaPadrao (false , true , false);

        
        test._removerConfiguracaoPadraoScrollbar(1);
        filho1._removerConfiguracaoPadraoScrollbar(1);
        filho2._removerConfiguracaoPadraoScrollbar(1);
        filho3._removerConfiguracaoPadraoScrollbar(1);
        filho4._removerConfiguracaoPadraoScrollbar(1);
        filho5._removerConfiguracaoPadraoScrollbar(1);

        test.atribuirTop="90%";
        test.atribuirLeft="14%";
        
        test.getCaixaFilha.atribuirBackgroundColor="black";
        test.atribuirBackgroundColor="#070707"
        filho1.atribuirBackgroundColor="#111111";
        filho2.atribuirBackgroundColor="#111111";
        filho3.atribuirBackgroundColor="#111111";
        filho4.atribuirBackgroundColor="#111111";
        filho5.atribuirBackgroundColor="#111111";
        filho1.getCaixaFilha.atribuirBackgroundColor="#111111";
        filho2.getCaixaFilha.atribuirBackgroundColor="#111111";
        filho3.getCaixaFilha.atribuirBackgroundColor="#111111";
        filho4.getCaixaFilha.atribuirBackgroundColor="#111111";
        filho5.getCaixaFilha.atribuirBackgroundColor="#111111";


        test.getCaixaFilha.atribuirWidth="95%";
        test.atribuirWidth="70%"

        filho1.atribuirWidth="95%";
        filho2.atribuirWidth="95%";
        filho3.atribuirWidth="95%";
        filho4.atribuirWidth="95%";
        filho5.atribuirWidth="95%";
        
        filho1.atribuirLeft = "0%"
        filho2.atribuirLeft = "0%"
        filho3.atribuirLeft = "0%"
        filho4.atribuirLeft = "0%"
        filho5.atribuirLeft = "0%"

        
        filho1.getCaixaFilha.atribuirTextContent="ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        filho5.getCaixaFilha.atribuirTextContent="ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"

        test._addChild(filho1.getElemento);
        test._addChild(filho2.getElemento);
        test._addChild(filho3.getElemento);
        test._addChild(filho4.getElemento);
        test._addChild(filho5.getElemento);

    
       
    }

}