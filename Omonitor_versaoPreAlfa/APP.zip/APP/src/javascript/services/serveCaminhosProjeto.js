export default class ServeCaminhosProjeto { 
    constructor() {
        this._closeFullscreenIcon = "../../assets/icons/close_fullscreen_24dp_F3F3F3_FILL0_wght400_GRAD0_opsz24.svg";
        this._openFullscreenIcon = "../../assets/icons/fullscreen_24dp_F3F3F3_FILL0_wght400_GRAD0_opsz24.svg";
        this._homeIcon = "../../assets/icons/home_24dp_F3F3F3_FILL0_wght400_GRAD0_opsz24.svg";
        this._perfilIcon= "../../assets/icons/person_24dp_F3F3F3_FILL0_wght400_GRAD0_opsz24.svg"
    }

    get closeFullscreenIcon() {
        return this._closeFullscreenIcon;
    }

    get openFullscreenIcon() {
        return this._openFullscreenIcon;
    }

    get homeIcon() {
        return this._homeIcon;
    }

     get perfilIcon() {
        return this._perfilIcon;
    }

    _serveUrlImage(caminho){
        return "url("+caminho+")";
    }
}